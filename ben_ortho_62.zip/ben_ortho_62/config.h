#define AZOTEQ_IQS5XX_TPS43
#define POINTING_DEVICE_BUTTONS 0  // Disable trackpad button support